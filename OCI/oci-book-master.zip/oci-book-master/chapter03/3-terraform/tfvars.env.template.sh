# Terraform
export TF_VAR_tenancy_ocid=<put-here-tenancy-ocid>
export TF_VAR_user_ocid=<put-here-user-ocid>
export TF_VAR_fingerprint=<put-here-api-signing-key-fingerprint>
export TF_VAR_region=<put-here-region-identifier>
export TF_VAR_private_key_path=<put-here-path-to-private-key>
export TF_VAR_private_key_password=<put-here-private-key-password>
export TF_VAR_compartment_ocid=<put-here-compartment-ocid>
