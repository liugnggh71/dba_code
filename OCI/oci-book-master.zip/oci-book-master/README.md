# Practical Oracle Cloud Infrastructure
:copyright: Michał Jakóbczyk  

This repository accompanies **Practical Oracle Cloud Infrastructure** by Michał Jakóbczyk (Apress, 2020).

https://www.apress.com/gp/book/9781484255056

![Cover](https://images.springer.com/sgw/books/medium/9781484255056.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

Last time code tested:  
:white_check_mark: macOS - December 2019  
:white_check_mark: Windows Substem for Linux - January 2020
