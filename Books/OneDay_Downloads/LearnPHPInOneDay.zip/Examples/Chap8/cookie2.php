<?php        
    echo 'User Name is '.$_COOKIE['userName'];
    echo '<BR>User Age is '.$_COOKIE['userAge'];
    echo 'User Level is '.$_COOKIE['userLevel'];
