<?php
//    header('Location: http://example.com');
?>        


<!DOCTYPE html>
<html>
    <body>        
        <?php 
            include 'heading.html';
//            include 'heading.html'; 
//            include_once 'heading.html';        
//            include_once 'heading.html';       
        
        ?>	
    </body>
</html>
