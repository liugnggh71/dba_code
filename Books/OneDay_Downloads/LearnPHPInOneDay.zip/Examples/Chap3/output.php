<?php
    //Add code below
    echo 'PHP is fun<BR>and easy!';

    echo '<BR>';
    echo "ABCD", "EFGH";

    echo '<BR>';
    echo ("ABCD");

//    echo ("ABCD", "EFGH");

    echo '<BR>';
    print "My name is Brody.";

//    echo '<BR>Today is Friday, we're going to the zoo.';

    echo "<BR>Today is Friday, we're going to the zoo.";

    echo '<BR>Today is Friday, we\'re going to the zoo.';

    echo '<BR>';
//    echo """;
    echo "\"";

    echo '<BR>';
//    echo "\";
    echo "\\";

