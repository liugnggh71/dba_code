<!DOCTYPE html>
<html>
<head>
    <title>My first PHP page</title>
</head>
    <body>
        <h1>My first PHP page</h1>
        <?php
            #Simple hello world page    
            echo "Hello World!";
        ?>
    </body>
</html>
