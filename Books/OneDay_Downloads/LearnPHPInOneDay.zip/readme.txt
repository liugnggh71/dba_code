Copy the "Examples" folder into htdocs.

Before running the code, ensure that you have started the Apache server. For Chapter 11, ensure that you have started MySQL server as well.

To load the PHP files, use the following URLs:

For Windows:
http://localhost/Examples/<Chapter_Folder_Name>/<File_Name>.php

For Mac (assuming you use port 8080):
http://localhost:8080/Examples/<Chapter_Folder_Name>/<File_Name>.php

For instance, to load hello.php in Chap2 on Windows, use http://localhost/Examples/Chap2/hello.php. 

To load it on Mac, use http://localhost:8080/Examples/Chap2/hello.php
