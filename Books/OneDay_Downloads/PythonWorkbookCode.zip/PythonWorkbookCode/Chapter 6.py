#Question 2

num = 5

if num == 1:
    print('num is 1')
elif num == 2:
    print('num is 2')
else:
    print('num is neither 1 nor 2')

#Question 3

userInput = int(input('Please enter an integer: '))

if userInput > 0:
    print(userInput)
elif userInput < 0:
    userInput = -1*userInput
    print(userInput)
else:
    print('You entered zero')

#Question 4

testScore = int(input('Please enter an integer from 0 to 100 inclusive: '))

if testScore > 100:
    print('Invalid')
elif testScore >= 70:
    print('A')
elif testScore >= 60:
    print('B')
elif testScore >= 50:
    print('C')
elif testScore >= 0:
    print('Fail')
else:
    print('Invalid')

#Question 5

num = 5

print('Orange Juice' if num == 5 else 'Peanut Butter')

#Question 6

num1 = int(input('Please enter an integer: '))

print('Even' if num1%2 == 0 else 'Odd')

#Question 7

myNumbers = [1, 21, 12, 45, 2, 7]

for i in myNumbers:
    print (i)

#Question 8

marks = [12, 4, 3, 17, 20, 19, 16]
sum = 0

for i in marks:
    sum = sum + i

print(sum)

#Question 9

classRanking = ['Jane', 'Peter', 'Michael', 'Tom']

for index, rank in enumerate(classRanking):
    print('%d\t%s' %(index+1, rank))

#Question 10

testScores = {'Aaron':12, 'Betty':17, 'Carol':14}

for i in testScores:
    print(i, 'scored', testScores[i], 'marks.')

#Question 11

ages = {'Abigail':7, 'Bond':13, 'Calvin':4}

for i, j in ages.items():
    print('%s\t%s' %(j, i))

#Question 12

message = 'Happy Birthday'

for i in message:
    if (i == 'a'):
        print('@')
    else:
        print(i)

#Question 13

for i in range(10):
    print (i)

for i in range(2, 5):
    print(i)

for i in range(4, 10, 2):
    print(i)

#Question 14

i = 0

while i < 5:
    print('The value of i = ', i)
    i = i + 1

#Question 15

i = 5

while i>0:
    if i%3 == 0:
        print(i, 'is a multiple of 3')
    else:
        print(i, 'is not a multiple of 3')

    i = i - 1

#Question 16

userInput = input('Enter a number or END to exit: ')

while userInput != 'END':
    print(userInput)
    userInput = input('Enter a number or END to exit: ')

print('Goodbye!')

#Question 17

sum = 0
userInput = int(input('Enter a positive integer or -1 to exit: '))

while userInput != -1:
    sum += userInput
    print('Sum = ', sum)
    print()
    userInput = int(input('Enter a positive integer or -1 to exit: '))

print('Goodbye!')

#Question 18

sum = 0
userInput = int(input('Enter a positive integer or -1 to exit: '))

while userInput != -1:
    if userInput <= 0:
        print('You entered a non positive integer.')
    else:
        sum += userInput
        print('Sum = ', sum)

    print()    
    userInput = int(input('Enter a positive integer or -1 to exit: '))
    
print('Goodbye!')

#Question 19

p = int(input('Please enter the number of rows: '))
q = int(input('Please enter the number of asterisks per row: '))

for i in range(p):
    for j in range(q):
        print('*', end = '')
    print()

#Question 20

message = input('Please enter a message: ')

j = 0

for i in message:
    if i == 'a':
        j = j + 1
        if j <= 3:
            print('@', end = '')
        else:
            print('A', end = '')
    else:
        print(i, end = '')

print()

#Question 21

for i in range(10):
    userInput = input('Please enter number %d: ' %(i+1))

    #Assign the first user input
    #to largest and smallest
    if i == 0:
        largest = userInput
        smallest = userInput
    #From the second user input onwards,
    #compare user input with 
    #current largest and smallest
    elif float(userInput) > float(largest):
        largest = userInput
    elif float(userInput) < float(smallest):
        smallest = userInput

print('The smallest number is %s' %(smallest))
print('The largest number is %s' %(largest))

#Question 22

a = int(input('Please enter the first integer: '))
b = int(input('Please enter the second integer: '))

'''if b is smaller than a, we swap the two numbers'''
if b<a:
    temp = b
    b = a
    a = temp
    
product = 1

for i in range(a, b+1):
    product = product*i

print(product)

#Question 23

a = int(input('Please enter the first integer: '))
b = int(input('Please enter the second integer: '))

'''if b is smaller than a, we swap the two numbers'''
if b<a:
    temp = b
    b = a
    a = temp
    
product = 1

for i in range(a, b+1):
    if i != 0:
        product = product*i
    if product > 500 or product < -500:
        product = -1
        break

if product == -1:
    print('Range Exceeded')
else:
    print(product)

#Question 24

while 0==0:
    userInput = input('Press any key to continue or -1 to exit: ')
    if userInput == '-1':
        break
    else:
        print('You entered', userInput)

#Question 25

for i in range(10):
    if i%2 == 0:
        continue
    print('i = ', i)

#Question 26

number = int(input('Enter a positive integer: '))

if number <= 0:
    print('The number you entered is not positive')
else:
    factorial = 1
    while number>0:
        factorial = number*factorial
        number -= 1
    print(factorial)

#Question 27

try:
    number = int(input('Enter a positive integer: '))
    if number <= 0:
        print('The number you entered is not positive')
    else:
        factorial = 1
        while number>0:
            factorial = number*factorial
            number -= 1
        print(factorial)
except ValueError:
    print('You did not enter an integer')
except Exception as e:
    print(e)

#Question 28

proLang = ['Python', 'Java', 'C', 'C++', 'C#', 'PHP', 'Javascript']

try:
    index = int(input('Please enter the index: '))
    print(proLang[index])
except IndexError:
    print('Out of Range')
except Exception as e:
    print(e)

#Question 29

#Solution 1
cities = {'Chicago':'USA', 'Los Angeles':'USA', 'New York':'USA', 'Osaka':'Japan', 'Tokyo':'Japan', 'Shanghai':'China', 'Moscow':'Russia', 'Paris':'France', 'London':'England', 'Seoul':'South Korea'}

print('Cities: Chicago, Los Angeles, New York, Osaka, Tokyo, Shanghai, Moscow, Paris, London, Seoul')

print()

city = input('Please enter a city name from the list above or enter END to exit: ')

while city != 'END':

    try:
        print('%s is located in %s.\n' %(city, cities[city]))
        city = input('Please enter a city name from the list above or enter END to exit: ')

    except:
        print('Sorry, no result found.\n')
        city = input('Please enter a city name from the list above or enter END to exit: ')

#Solution 2
cities = {'Chicago':'USA', 'Los Angeles':'USA', 'New York':'USA', 'Osaka':'Japan', 'Tokyo':'Japan', 'Shanghai':'China', 'Moscow':'Russia', 'Paris':'France', 'London':'England', 'Seoul':'South Korea'}

print('Cities: Chicago, Los Angeles, New York, Osaka, Tokyo, Shanghai, Moscow, Paris, London, Seoul')

print()

city = input('Please enter a city name from the list above or enter END to exit: ')

while city != 'END':

    try:
        print('%s is located in %s.\n' %(city, cities[city]))     
   
    except:
        print('Sorry, no result found.\n')

    finally:
        city = input('Please enter a city name from the list above or enter END to exit: ')
