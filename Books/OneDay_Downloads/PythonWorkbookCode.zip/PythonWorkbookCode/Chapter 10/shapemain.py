from shape import Square, Circle, Triangle

sq = Square(5)
c = Circle(10)
t = Triangle(12, 4)

print(sq)
print(c)
print(t)

print(sq + c)
print(sq + c + t)
