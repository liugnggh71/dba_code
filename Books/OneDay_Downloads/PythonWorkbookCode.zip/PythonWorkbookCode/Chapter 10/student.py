# Student Class

class Student:

    def __init__(self, pName, pID, pCourseEnrolled, pAnnualFees):
        self.name = pName
        self.id = pID
        self.course_enrolled = pCourseEnrolled
        self.annual_fees = pAnnualFees

    def __str__(self):
        return 'Name = %s\nID = %s\nCourse Enrolled = %s\nAnnual Fees = %s' %(self.name, self.id, self.course_enrolled, self.annual_fees)

    def __lt__(self, other):
        return self.annual_fees < other.annual_fees

    def __gt__(self, other):
        return self.annual_fees > other.annual_fees

# ArtsStudent subclass 

class ArtsStudent(Student):

    def __init__(self, pName, pID, pCourseEnrolled, pAnnualFees, pProjectGrade):
        super().__init__(pName, pID, pCourseEnrolled, pAnnualFees)
        self.project_grade = pProjectGrade

    def __str__(self):
        return super().__str__() + '\nProject Grade = %s' %(self.project_grade)

# CommerceStudent subclass 

class CommerceStudent(Student):

    def __init__(self, pName, pID, pCourseEnrolled, pAnnualFees, pInternshipCompany):
        super().__init__(pName, pID, pCourseEnrolled, pAnnualFees)
        self.internship_company = pInternshipCompany

    def __str__(self):
        return super().__str__() + '\nInternship Company = %s' %(self.internship_company)

# TechStudent subclass 

class TechStudent(Student):

    def __init__(self, pName, pID, pCourseEnrolled, pAnnualFees, pProjectGrade, pInternshipCompany):
        super().__init__(pName, pID, pCourseEnrolled, pAnnualFees)
        self.project_grade = pProjectGrade
        self.internship_company = pInternshipCompany        

    def __str__(self):
        return super().__str__() + '\nProject Grade = %s\nInternship Company = %s' %(self.project_grade, self.internship_company)
