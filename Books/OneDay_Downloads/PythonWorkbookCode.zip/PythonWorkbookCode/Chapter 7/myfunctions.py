def func1():
    print('This is a simple function')

def func2(message):
    print(message)
