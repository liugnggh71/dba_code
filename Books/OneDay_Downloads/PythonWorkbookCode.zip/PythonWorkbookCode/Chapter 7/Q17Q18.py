import sys

if 'C:\\PythonFiles' not in sys.path:
    sys.path.append('C:\\PythonFiles')
    

import myfunctions
myfunctions.func1()
myfunctions.func2('Hello')

##import myfunctions as f
##f.func1()
##f.func2('Hello')

##from myfunctions import func1, func2
##func1()
##func2('Hello')
