#Question 1

def greetUser():
    print('Hello World')

greetUser()

#Question 2

def greetUserByName():
    name = input('Please enter your name: ')
    print('Hello %s' %(name))

greetUserByName()

#Question 3

def displayMessage(greetings):
    print(greetings)

displayMessage('Good Morning')

#Question 4

def calculateQuotient(a, b):
    return a/b

result = calculateQuotient(12, 3)
print(result)

#Question 5

def calculateQuotient2(a, b):
    try:
        return a/b
    except:
        return -1

result = calculateQuotient2(12, 3)
print(result)

result = calculateQuotient2(5, 0)
print(result)

result = calculateQuotient2('abcd', 2)
print(result)

#Question 6

def absValue(a):
    try:
        num = float(a)
        if num >= 0:
            return a
        else:
            return -1*a
    except Exception as e:
        return -1
    
result = absValue(12)
print(result)

result = absValue(5.7)
print(result)

result = absValue(0) 
print(result)

result = absValue(-4) 
print(result)

result = absValue(-5.2) 
print(result)

result = absValue('abcd') 
print(result)

#Question 7

a = 1
def displayNumbers():
    a = 2
    print(a)

displayNumbers()
print(a)

#Question 9

def calProduct(a, b, c = 1, d = 2):
    product = a*b*c*d
    print (product)

calProduct(2, 3)
calProduct(2, 3, 4)
calProduct(2, 3, 4, 5)

#Question 10

def teamMembers(a, b, c = 'James', d = 'Kelly'):
    print('The team members are %s, %s, %s and %s.' %(a, b, c, d))

teamMembers('Joanne', 'Lee')
teamMembers('Benny', 'Aaron')
teamMembers('Peter', 'John', 'Ben')
teamMembers('Jamie', 'Adam', 'Calvin', 'Danny')

#Question 11

def findSum(*a):
    sum = 0
    for i in a:
        sum = sum + i

    print(sum)

findSum(1, 2, 3)
findSum(1, 2, 3, 4)

#Question 12

def printFavColor(*color):
    print('Your favorite colors are:')
    for i in color:
        print(i)

printFavColor('Yellow', 'Green')
printFavColor('Orange', 'Pink', 'Blue')

#Question 13

def printNamesAndGrades(**grades):
    print('Name : Grade')
    for i in grades:
        print('%s : %s' %(i, grades[i]))

printNamesAndGrades(Adam = 'C', Tim = 'A')
printNamesAndGrades(Sam = 'A-', Lee = 'B', Joan = 'A+')

#Question 14

def varlengthdemo(a, *b, **c):
    print(a)
    for i in b:
        print (i)
    for j, k in c.items():
        print (j, 'scored', k)

varlengthdemo('Jeremy', 2, 3, 4, Apple = 'A', Betty = 'B')

#Question 15

def sumOfTwoNumbers(target, *b):

    length = len(b)

    for p in range(length-1):
        for q in range(p+1, length):
            if b[p] + b[q] == target:
                print(b[p],'+',b[q],'=',target)
                return
    print ('No result found')

sumOfTwoNumbers(12, 3, 1, 4, 5, 6, 13)

sumOfTwoNumbers(5, 3, 1, 4, 2)

#Question 16

def capitalsOfCountries(**capitals):
    if(len(capitals) == 1):
        print('The capital of ', end = '')
    else:
        print('The capitals of ', end = '')

    # Print the country names    
    for i, j in enumerate(capitals):
        if i == 0:
            print(j, end = '')
        elif i == len(capitals)-1:
            print(' and %s' %(j), end = '')
        else:
            print(', %s' %(j), end = '')
        
    if(len(capitals) == 1):
        print(' is ', end = '')
    else:
        print(' are ', end = '')

    # Print the capitals
    for i, j in enumerate(capitals):
        if i == 0:
            print(capitals[j], end = '')
        elif i == len(capitals)-1:
            print(' and %s' %(capitals[j]), end = '')
        else:
            print(', %s' %(capitals[j]), end = '')

    if len(capitals) == 1:
        print('.')
    else:
        print(' respectively.')
                
capitalsOfCountries(Germany = 'Berlin')
capitalsOfCountries(USA = 'Washington D.C.', China = 'Beijing')
capitalsOfCountries(Japan = 'Tokyo', Indonesia = 'Jakarta', France = 'Paris')

