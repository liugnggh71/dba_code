#Question 1

name1 = 'Jamie'
print(name1)

name2 = 'Aaron'.upper()
print(name2)

message = 'The names are %s and %s.' %(name1, name2)
print(message)

#Question 2

lang1 = 'Python'
lang2 = 'Java'
lang3 = 'C#'

message1 = 'The most popular programming languages are %s, %s and %s.' %(lang1, lang2, lang3)

message2 = 'The most popular programming languages are %s, %s and %s.' %(lang1, lang3, lang2)

print(message1)
print(message2)

#Question 3

num = 12

message = '%d' %(num)
print(message)

message = '%4d' %(num)
print(message)

#Question 4

decnum = 1.72498329745

message = '%5.3f' %(decnum)
print(message)

message = '%7.2f' %(decnum)
print(message)

#Question 5

p, q = 111, 13
result = p/q

message = 'The result of %d divided by %d is %.3f, correct to 3 decimal places.' %(p, q, result)

print(message)

#Question 6

message = 'My name is {} and I am {} years old.'.format('Jamie', 31) 
print(message)

#Question 7

message1 = 'My favorite colors are {}, {} and {}.'.format('orange', 'blue', 'black')

message2 = 'My favorite colors are {1}, {0} and {2}.'.format('orange', 'blue', 'black')

print(message1)
print(message2)

#Question 8

student1 = 'Aaron'
student2 = 'Beck'
student3 = 'Carol'

message = 'My best friends are {}, {} and {}.'.format(student1, student2, student3)

print(message)

#Question 9

message1 = '{:7.2f} and {:d}'.format(21.3124, 12)

message2 = '{1} and {0}'.format(21.3124, 12)

print(message1)
print(message2)

#Question 10

x, y = 12, 7
quotient = x/y

message = 'The result of {} divided by {} is {:.4f}, correct to 4 decimal places.'.format(x, y, quotient)

print(message)

#Question 11

number = 2.7123
number = int(number)
print(number)

#Question 12

str(2.12431)

#Question 13

userInput = '12'
userInput = int(userInput)
print(userInput)

#Question 15

testScores = [10, 11, 12, 13]
print(testScores[3])
print(testScores[-1])

#Question 16

myList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
myList1 = myList
myList2 = myList[3:6]
myList3 = myList[:5]
myList4 = myList[2:]
myList5 = myList[1:7:2]
myList6 = myList[ : :3]

print(myList)
print(myList1)
print(myList2)
print(myList3)
print(myList4)
print(myList5)
print(myList6)

#Question 17

q17 = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

sliceA = q17[2:8]
sliceB = q17[2: :3]

print(sliceA)
print(sliceB)

#Question 18

emptyList = []

emptyList.append(12)
emptyList.append(5)
emptyList.append(9)
emptyList.append(11)

print(emptyList)

#Question 19

q19 = [1, 2, 3, 4, 5]
q19[2] = 10
print(q19)

#Question 20

q20 = ['A', 'B', 'C', 'D', 'E']

del q20[2]
del q20[0]

print(q20)

#Question 21

daysOfWeek = ('Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat')

myDay = daysOfWeek[2]
print(myDay)

#Question 23

dict1 = {'Aaron': 11, 'Betty': 5, 0: 'Zero', 3.9: 'Three'}

print(dict1['Aaron'])

print(dict1[0])

print(dict1[3.9])

dict1['Aaron'] = 12
print(dict1)

del dict1['Betty']
print(dict1)

#Question 24

dict1 = dict(One = 1, Two = 2, Three = 3, Four = 4, Five = 5)
print(dict1['Four'])
dict1['Three'] = 3.1
del dict1['Two']
print(dict1)

#Question 25

capitals = {'USA':'Washington, D.C.', 'United Kingdom':'London', 'China':'Beijing', 'Japan':'Tokyo', 'France':'Paris'}
print(capitals)

del capitals['China']
print(capitals)

capitals['Germany'] = 'Berlin'
capitals['Malaysia'] = 'Kuala Lumpur'
print(capitals)
