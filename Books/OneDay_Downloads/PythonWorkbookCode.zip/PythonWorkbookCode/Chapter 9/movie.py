class Movies:
    def __init__(self, pTitle, pGenre, pLanguage, pDirectors, pYear):
        self.title = pTitle
        self._genre = pGenre
        self.language = pLanguage
        self.directors = pDirectors
        self.year = pYear

    def __str__(self):
        return 'Title = %s\nGenre = %s\nLanguage = %s\nDirectors = %s\nYear = %s\n' %(self.title, self._genre, self.language, self.directors, self.year)
    
    @property
    def genre(self):
        return self._genre

    @genre.setter
    def genre(self, value):
        if value in ['Romance', 'Action', 'Drama', 'Thriller', 'Horror']:
            self._genre = value
        else:
            print ('%s is an invalid genre.\n' %(value))

    def recommendMovie(self):
        recommendations = {'Romance':'First Date', 'Action':'Mutant', 'Drama':'The Awakening', 'Thriller':'Mr K', 'Horror':'A walk down Dawson Street'}
        print ('You may also like the following movie: %s.' %(recommendations[self._genre]))
