from movie import Movies

mov1 = Movies('And so it begins', '', 'English', 'Robert Kingman, Joe Patterson', 2019)

mov1.genre = 'Fantasy'

mov1.genre = 'Romance'
print(mov1)
mov1.recommendMovie()
