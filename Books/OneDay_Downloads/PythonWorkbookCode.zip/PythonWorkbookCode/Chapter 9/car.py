class Car:

    def __init__(self, pMake, pModel, pColor, pPrice):
        self.make = pMake
        self.model = pModel
        self.color = pColor
        self.price = pPrice

    def __str__(self):
        return 'Make = %s, Model = %s, Color = %s, Price = %s' %(self.make, self.model, self.color, self.price)

    def selectColor(self):
        self.color = input('What is the new color? ')

    def calculateTax(self):
        priceWithTax = 1.1*self.price
        return priceWithTax


myFirstCar = Car('Honda', 'Civic', 'White', 15000)
print(myFirstCar)
myFirstCar.price = 18000
print(myFirstCar)
myFirstCar.selectColor()
print(myFirstCar)
finalPrice = myFirstCar.calculateTax()
print(finalPrice)
