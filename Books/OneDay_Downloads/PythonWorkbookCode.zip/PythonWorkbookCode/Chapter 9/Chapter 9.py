#Question 2

class Room:

    def __init__(self, pSize, pView, pType, pBasicRates):
        self.size = pSize
        self.view = pView
        self.type = pType
        self.basicRates = pBasicRates

    def __str__(self):
        return 'Size = %s sq ft\nView = %s\nType = %s\nBasic Rates = USD%s' %(self.size, self.view, self.type, self.basicRates)

    def calculateRates(self, day):
        if day == 'Weekends':
            return 1.5*self.basicRates
        elif day == 'Public Holidays':
            return 2*self.basicRates
        elif day == 'Christmas':
            return 2.5*self.basicRates
        else:
            return 1*self.basicRates

room1 = Room(132, 'City', 'Double', 120)
print(room1)

newRates = room1.calculateRates('Public Holidays')
print(newRates)

#Question 3

class HumanResource:
    def __init__(self, pName, pSalary, pBonus):
        self.name = pName
        self.salary = pSalary
        self._bonus = pBonus

    def __str__(self):
        return 'Name = %s, Salary = %.2f, Bonus = %.2f' %(self.name, self.salary, self._bonus)

    @property
    def bonus(self):
        return self._bonus        

    @bonus.setter
    def bonus(self, value):
        if value < 0:
            print('Bonus cannot be negative')
        else:
            self._bonus = value

chiefOps = HumanResource('Kelly', 715000, 0)
chiefOps.bonus = -20
chiefOps.bonus = 50000
print(chiefOps.bonus)

#Question 5

class Book:
    message = 'Welcome to Books Online'
    
    def __init__(self, pTitle, pAuthor, pPrice):
        self.title = pTitle
        self.author = pAuthor
        self.price = pPrice

    def __str__(self):
        return 'Title = %s, Author = %s, Price = %.2f' %(self.title, self.author, self.price)

aRomanceBook = Book('Sunset', 'Jerry', 10)
aSciFiBook = Book('Viz', 'Lee', 10)

aRomanceBook.price = 20
print(aRomanceBook.price)
print(aSciFiBook.price)

Book.message = 'Books Online'
print(aRomanceBook.message)
print(aSciFiBook.message)

#Question 6

class Student:

    passingMark = 50

    def __init__(self, pName, pMarks):
        self.name = pName
        self.marks = pMarks

    def __str__(self):
        return 'Name of Student = %s\nMarks = %d' %(self.name, self.marks)

    def passOrFail(self):
        if self.marks >= Student.passingMark:
            return 'Pass'
        else:
            return 'Fail'

student1 = Student('John', 52)
status1 = student1.passOrFail()
print(status1)

student2 = Student('Jenny', 69)
status2 = student2.passOrFail()
print(status2)

Student.passingMark = 60
status1 = student1.passOrFail()
print(status1)
status2 = student2.passOrFail()
print(status2)

#Question 7

class MethodsDemo:
    message = 'Class message'

    def __init__(self, pMessage):
        self.message = pMessage

    @classmethod
    def printMessage(cls):
        print(cls.message)

    def printAnotherMessage(self):
        print(self.message)

    @staticmethod
    def printThirdMessage():
        print('This is a static method')

md1 = MethodsDemo('md1 Instance Message')

md1.printMessage()
MethodsDemo.printMessage()

md1.printThirdMessage()
MethodsDemo.printThirdMessage()
