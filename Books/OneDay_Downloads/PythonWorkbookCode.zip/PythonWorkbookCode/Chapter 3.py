#Question 1

myFavNumber = 11

#Question 2

myFavWord = 'Python'

#Question 3

userName = 'Lee'
print(userName)
userName = 'James'
print(userName)

#Question 4

num1 = 5
NUM1 = 7

print(num1)
print(NUM1)

#Question 6

a = 17
b = 12
a = b
print(a)

#Question 7

x, y = 5, 4

print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x//y)
print(x%y)
print(x**y)

#Question 8

a = 12
b = 5

sum = a + b
product = a*b
remainder = a%b

print(sum)
print(product)
print(remainder)

#Question 9

a = 13
b = 7
c = 5

result = (a+c)*b + c - a
print(result)

#Question 10

s = 12
s = s - 3
print(s)

#Question 11

num = 5
num = num + 10
print(num)

#Question 12

t = 10
t = t + 1
t = t*2
t = t/5
print(t)

#Question 13

p, q = 12, 4

p += 3
print(p)

q **= 2
print(q)

#Question 14

r = 11
s = 7
r = r + s
print(r)
print(s)

#Question 15 

number = 10
number = number + 17
number = number*2
number = number - 4
number = number*2
number = number + 20
number = number/4
number = number - 20

print(number)
