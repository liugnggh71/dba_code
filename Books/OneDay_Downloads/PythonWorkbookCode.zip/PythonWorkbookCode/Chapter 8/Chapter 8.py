#Question 1

f = open('ch8q1.txt', 'r')

for i in range(4):
    line = f.readline()
    print(line, end = '')

f.close()

#Question 2

f = open('ch8q2.txt', 'r')
sum = 0

for line in f:
    if int(line) > 0:
        sum = sum + int(line)

print(sum)
    
f.close()

#Question 4

def getNumbers():

    f = open('ch8q4.txt', 'w')
    
    userInput = input('Enter an integer or type Q to exit: ')

    while userInput != 'Q':    
        try:
            num = int(userInput)
            f.write(userInput + '\n')
        except:
            print('Input is not an integer and will be ignored')
        finally:
            userInput = input('Enter an integer or type Q to exit: ')

    f.close()

def findSum():

    f = open('ch8q4.txt', 'r')
    sum = 0
    for line in f:
        sum = sum + int(line)

    f.close()

    return sum
            
getNumbers()
print(findSum())
    
#Question 5

f = open('stars.txt', 'r')

for i in range(9):
    line = f.read(i+1)
    print(line)

f.close()

#Question 6

from os import rename, remove

oldfile = open('C:\\images\\happy.jpg', 'rb')
newfile = open('newhappy.jpg', 'wb')

msg = oldfile.read(10)

while len(msg):
    newfile.write(msg)
    msg = oldfile.read(10)

oldfile.close()
newfile.close()

rename('newhappy.jpg', 'happy.jpg')
remove('C:\\images\\happy.jpg')
