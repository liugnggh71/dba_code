package modifierdemo;

public class ModifierDemo {
    
    public int publicNum = 2;
    protected int protectedNum = 3;
    int packagePrivateNum = 4;
    private int privateNum = 1;
    
}
