package helloworld;

public class HelloWorld {

    public static void main(String[] args) {
        //Print the words Hello World on the screen    
        System.out.println("Hello World");
    }
    
}
