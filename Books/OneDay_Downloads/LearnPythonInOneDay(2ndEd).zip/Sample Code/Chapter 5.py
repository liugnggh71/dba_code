#------------input() and print() Example-----------------

print("\n\ninput() and print() Example")
print("---------------------")

myName = input("Please enter your name: ")
myAge = input("What about your age: ")

print ("Hello World, my name is", myName, "and I am", myAge, "years old.")
