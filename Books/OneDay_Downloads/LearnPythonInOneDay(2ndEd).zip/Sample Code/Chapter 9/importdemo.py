#from myclass import SomeClass, SomeOtherClass
import myclass

#sc = SomeClass()
sc = myclass.SomeClass()
sc.someMethod(100)

#soc = SomeOtherClass()
soc = myclass.SomeOtherClass()
