class SomeClass:
    def __init__(self):
        print('This is SomeClass')
    def someMethod(self, a):
        print('The value of a is', a)
        self.b = 5

class SomeOtherClass:
    def __init__(self):
        print('This is SomeOtherClass')
    
